Noah Ransom

All work in this submission is my own

As with my other homeworks, to run this, simply compile and execute as normal, and enter your input.
When you finish, press CTRL-D on linux and CTRL-V on windows to generate an EOF character and run.

Because this algorithm is horribly inefficient, it takes a really long time to run for fully connected graphs
with more than 7 islands, and my test data reflects this.

The tests with partially connected islands connected even islands to odd islands only, thus cutting
    the number of edges in half.

For information about testing, consult the test class. As in Homework5, I wrote my raw data to a file, included in my submission.
To run the test program, simply compile and run it as usual. If no test data file exists, it will create a new one. If one exists, it will append to it.
